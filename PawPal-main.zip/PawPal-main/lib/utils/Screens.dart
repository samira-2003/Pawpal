import 'package:pawpal/Pages/Hospitals.dart';
import 'package:flutter/material.dart';
import 'package:pawpal/Pages/MainPage.dart';

List<Widget> screens = const [
  MainPage(),
  Hopsital(),

  //NewsandEvent()
];
