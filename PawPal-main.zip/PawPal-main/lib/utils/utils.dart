import 'package:pawpal/themes.dart';
// import 'package:agro_tech/req/images.dart';

ThemeColor themeColor = ThemeColor();

// Images image = Images();
