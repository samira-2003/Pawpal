import 'package:flutter/material.dart';

class ThemeColor {
  final Color yellow = Color.fromARGB(255, 249, 222, 71);
  final Color mildyellow = Color.fromARGB(255, 254, 239, 173);
  final Color mildblue = Color.fromARGB(255, 104, 210, 232);
  final Color blue = Color.fromARGB(255, 3, 174, 210);
}
